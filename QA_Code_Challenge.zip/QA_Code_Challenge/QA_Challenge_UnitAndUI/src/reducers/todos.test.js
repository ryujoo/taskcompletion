/*
reducers sample pseudo code test:
Test 1:
I would pass in an undefined state and empty action as inputs and check that the output returns the initial state.


Add a few more tests below that you think help verify the logic and expected behaviour. 
Do not over test.



Test 2:
I would check whether action has a valid id and text to pass in


Test 3:
I would check whether it handles a todo when added 






*/
