/*
Todo component sample pseudo code test:
Test 1:
I would render the Todo component and check that the text decoration style is set to none by default


Add a few more tests below that you think help verify the logic and expected behaviour. 
Do not over test.


Test 2: 
I would check whether onClick function is working properly as a callback to invoke when a todo is clicked

Test 3:
I would check whether completed is a boolean value to show whether todo should appear crossed out or not

Test 4:
I would check whether text is a string



*/
